public class MobileApp {
    public void sendOverrideCommandToControlUnit(ControlUnit controlUnit) {
        // Logic to send override command
        System.out.println("Override command sent from MobileApp to Control Unit.");
    }
}