public class ControlUnit {
        public void receiveSignalFromSensor(MotionSensor sensor) {
            // Logic to process the signal
            processSignal();
        }

        public void processSignal() {
            // Logic to process the signal from sensor
            sendCommandToSmartLight();
        }

        public void sendCommandToSmartLight(SmartLight light) {
            light.turnOn();
        }
    }

