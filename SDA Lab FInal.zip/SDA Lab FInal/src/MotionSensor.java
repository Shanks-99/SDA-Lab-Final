 public class MotionSensor {
        public boolean detectMotion() {
            // Logic to detect motion
            return true; // Assuming motion is detected
        }

        public void sendSignalToControlUnit(ControlUnit controlUnit) {
            controlUnit.receiveSignalFromSensor(this);
        }
    }

