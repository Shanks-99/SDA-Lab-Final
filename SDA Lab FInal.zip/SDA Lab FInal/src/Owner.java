public class Owner {
    private MobileApp mobileApp;

    public Owner(MobileApp mobileApp) {
        this.mobileApp = mobileApp;
    }

    public void overrideControl() {
        mobileApp.sendOverrideCommandToControlUnit();
    }
}
