
    public class SmartLight {
        private boolean isOn;

        public void turnOn() {
            isOn = true;
            System.out.println("Smart Light is ON");
        }

        public void turnOff() {
            isOn = false;
            System.out.println("Smart Light is OFF");
        }
    }

